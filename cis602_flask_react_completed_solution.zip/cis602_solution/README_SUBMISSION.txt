CIS-602 Flask + React Activity - Completed Solution

What is included:
1. Fixed Flask backend (app.py)
2. Completed React frontend source in _frontend/users
3. Prebuilt dist folder so python app.py can serve the UI immediately
4. requirements.txt

How to run locally:
1. Open terminal in this project folder
2. Create venv:
   python -m venv env
3. Activate venv
   Windows: env\Scripts\activate
   Mac/Linux: source env/bin/activate
4. Install packages:
   pip install -r requirements.txt
5. Start app:
   python app.py
6. Open database init URL once:
   http://127.0.0.1:5000/init
7. Open app:
   http://127.0.0.1:5000/

If your professor wants the React build steps too:
1. cd _frontend/users
2. npm install
3. npm run build
4. Go back to root folder and run python app.py

Important:
- Take your own screenshots after running it on your machine or Codespaces.
- The README in the original repo requires browser and terminal screenshots in the submission zip.
