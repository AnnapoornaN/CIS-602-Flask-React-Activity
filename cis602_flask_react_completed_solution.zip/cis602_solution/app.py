from pathlib import Path
import sqlite3
from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS

BASE_DIR = Path(__file__).resolve().parent
DIST_DIR = BASE_DIR / 'dist'
ASSETS_DIR = DIST_DIR / 'assets'
DB_PATH = BASE_DIR / 'mydatabase.db'

app = Flask(__name__, static_folder=str(ASSETS_DIR), template_folder=str(DIST_DIR))
CORS(app)


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def ensure_database() -> None:
    conn = get_connection()
    conn.execute(
        '''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL
        )
        '''
    )
    conn.commit()
    conn.close()


@app.route('/init', methods=['GET'])
def create_database():
    created_before = DB_PATH.exists()
    ensure_database()
    return 'Database already exists!' if created_before else 'Database created!'


@app.route('/api/users', methods=['GET'])
def get_users():
    ensure_database()
    conn = get_connection()
    rows = conn.execute('SELECT id, name, email FROM users ORDER BY id').fetchall()
    conn.close()
    return jsonify([dict(row) for row in rows])


@app.route('/api/users', methods=['POST'])
def create_user():
    ensure_database()
    payload = request.get_json(silent=True) or {}
    name = str(payload.get('name', '')).strip()
    email = str(payload.get('email', '')).strip()

    if not name or not email:
        return jsonify({'error': 'Name and email are required.'}), 400

    conn = get_connection()
    cursor = conn.execute(
        'INSERT INTO users (name, email) VALUES (?, ?)',
        (name, email),
    )
    conn.commit()
    new_id = cursor.lastrowid
    conn.close()
    return jsonify({'id': new_id, 'name': name, 'email': email}), 201


@app.route('/api/users/<int:user_id>', methods=['GET'])
def get_user(user_id: int):
    ensure_database()
    conn = get_connection()
    row = conn.execute(
        'SELECT id, name, email FROM users WHERE id = ?',
        (user_id,),
    ).fetchone()
    conn.close()
    if row is None:
        return jsonify({'error': 'User not found'}), 404
    return jsonify(dict(row))


@app.route('/api/users/<int:user_id>', methods=['PUT'])
def update_user(user_id: int):
    ensure_database()
    payload = request.get_json(silent=True) or {}
    name = str(payload.get('name', '')).strip()
    email = str(payload.get('email', '')).strip()

    if not name or not email:
        return jsonify({'error': 'Name and email are required.'}), 400

    conn = get_connection()
    cursor = conn.execute(
        'UPDATE users SET name = ?, email = ? WHERE id = ?',
        (name, email, user_id),
    )
    conn.commit()
    conn.close()

    if cursor.rowcount == 0:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({'message': 'User updated successfully'})


@app.route('/api/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id: int):
    ensure_database()
    conn = get_connection()
    cursor = conn.execute('DELETE FROM users WHERE id = ?', (user_id,))
    conn.commit()
    conn.close()

    if cursor.rowcount == 0:
        return jsonify({'error': 'User not found'}), 404
    return jsonify({'message': 'User deleted successfully'})


@app.route('/assets/<path:filename>')
def serve_assets(filename: str):
    return send_from_directory(ASSETS_DIR, filename)


@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_react_app(path: str):
    if path.startswith('api') or path == 'init':
        return jsonify({'error': 'Not found'}), 404

    target = DIST_DIR / path
    if path and target.exists() and target.is_file():
        return send_from_directory(DIST_DIR, path)
    return send_from_directory(DIST_DIR, 'index.html')


if __name__ == '__main__':
    ensure_database()
    app.run(debug=True, host='0.0.0.0', port=5000)
