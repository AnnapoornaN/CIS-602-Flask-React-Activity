import React, { useEffect, useMemo, useState } from 'react'
import axios from 'axios'
import 'bootstrap/dist/css/bootstrap.min.css'
import { Alert, Button, Col, Container, Form, Row, Table } from 'react-bootstrap'
import './App.css'

const URL = '/api'
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/

export default function App() {
  const [users, setUsers] = useState([])
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [editingId, setEditingId] = useState(null)
  const [message, setMessage] = useState('')
  const [error, setError] = useState('')

  const isValidEmail = useMemo(() => email === '' || emailRegex.test(email), [email])

  const loadUsers = async () => {
    try {
      const response = await axios.get(`${URL}/users`)
      setUsers(response.data)
    } catch (err) {
      setError('Unable to load users.')
      console.error(err)
    }
  }

  useEffect(() => {
    loadUsers()
  }, [])

  const resetForm = () => {
    setName('')
    setEmail('')
    setEditingId(null)
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    setMessage('')
    setError('')

    if (!name.trim() || !email.trim()) {
      setError('Please enter both name and email.')
      return
    }
    if (!emailRegex.test(email.trim())) {
      setError('Please enter a valid email address.')
      return
    }

    try {
      if (editingId === null) {
        const response = await axios.post(`${URL}/users`, { name: name.trim(), email: email.trim() })
        setUsers([...users, response.data])
        setMessage('User added successfully.')
      } else {
        await axios.put(`${URL}/users/${editingId}`, { name: name.trim(), email: email.trim() })
        setUsers(users.map((user) => (user.id === editingId ? { ...user, name: name.trim(), email: email.trim() } : user)))
        setMessage('User updated successfully.')
      }
      resetForm()
    } catch (err) {
      setError('Something went wrong while saving the user.')
      console.error(err)
    }
  }

  const handleEdit = (user) => {
    setEditingId(user.id)
    setName(user.name)
    setEmail(user.email)
    setMessage('')
    setError('')
  }

  const handleDelete = async (id) => {
    setMessage('')
    setError('')
    try {
      await axios.delete(`${URL}/users/${id}`)
      setUsers(users.filter((user) => user.id !== id))
      if (editingId === id) {
        resetForm()
      }
      setMessage('User deleted successfully.')
    } catch (err) {
      setError('Something went wrong while deleting the user.')
      console.error(err)
    }
  }

  return (
    <Container className="py-4">
      <h1 className="page-title">Flask Based CRUD Application</h1>

      <Row className="g-4">
        <Col md={4}>
          <div className="form-card">
            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-3">
                <Form.Label>Name</Form.Label>
                <Form.Control
                  type="text"
                  placeholder="Enter name"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Email address</Form.Label>
                <Form.Control
                  type="email"
                  placeholder="Enter email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  isInvalid={email !== '' && !isValidEmail}
                />
                <Form.Control.Feedback type="invalid">Please enter a valid email.</Form.Control.Feedback>
              </Form.Group>

              <div className="action-buttons">
                <Button type="submit">{editingId === null ? 'Add User' : 'Update User'}</Button>
                {editingId !== null && (
                  <Button variant="secondary" type="button" onClick={resetForm}>
                    Cancel
                  </Button>
                )}
              </div>
            </Form>

            {message && <Alert className="mt-3" variant="success">{message}</Alert>}
            {error && <Alert className="mt-3" variant="danger">{error}</Alert>}
          </div>
        </Col>

        <Col md={8}>
          <div className="table-card">
            <Table striped bordered hover responsive>
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {users.length === 0 ? (
                  <tr>
                    <td colSpan="4" className="text-center">No users found.</td>
                  </tr>
                ) : (
                  users.map((user) => (
                    <tr key={user.id}>
                      <td>{user.id}</td>
                      <td>{user.name}</td>
                      <td>{user.email}</td>
                      <td>
                        <div className="action-buttons">
                          <Button size="sm" onClick={() => handleEdit(user)}>Edit</Button>
                          <Button size="sm" variant="danger" onClick={() => handleDelete(user.id)}>Delete</Button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </Table>
          </div>
        </Col>
      </Row>
    </Container>
  )
}
